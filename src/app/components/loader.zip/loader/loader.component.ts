import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { interval, map, Observable, Observer, Subscription, tap } from 'rxjs';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {

  
  @ViewChild('progressbar')progressbar!:ElementRef;

  progressBarSubscription!:Subscription;
  dynamicWidth!:number;
  progresspercentage!:number;
  constructor(private el:ElementRef,private renderer:Renderer2) { 
  }

  ngOnInit(): void {

  }

  ngAfterViewInit(){
    this.progressBarSubscription=interval(1000)
      .pipe(
        map(data=>data*10),
      ).subscribe(data=>{
        this.progresspercentage=data;
          if(data==100){
            this.progressBarSubscription.unsubscribe()
          }
          this.progressbar.nativeElement.style.width=data+'%'
      })

    
  }


   ngOnDestroy(){
      this.progressBarSubscription.unsubscribe()
   }

}
